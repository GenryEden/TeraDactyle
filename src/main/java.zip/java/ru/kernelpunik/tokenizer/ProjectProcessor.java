package ru.kernelpunik.tokenizer;

import org.treesitter.TSLanguage;
import org.treesitter.TSParser;
import ru.kernelpunik.teradactyle.models.Component;
import ru.kernelpunik.teradactyle.models.Fingerprint;
import ru.kernelpunik.teradactyle.models.Language;
import ru.kernelpunik.teradactyle.repositories.FingerprintRepository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.logging.Logger;

public class ProjectProcessor {
    private final static double MIN_PERCENT = 0.5; // TODO: move it to config and parameters
    final Fingerprinter fingerprinter;
    final FingerprintRepository fingerprintRepository;
    final Language language;

    public ProjectProcessor(TSLanguage language, FingerprintRepository fingerprintRepository) {
        TSParser tsParser = new TSParser();
        tsParser.setLanguage(language);
        fingerprinter = new Fingerprinter(tsParser);
        this.fingerprintRepository = fingerprintRepository;
        this.language = Language.getByTsLanguage(language);
        Objects.requireNonNull(this.language, "Given language was not found");
    }

    public CollisionReport processSource(File file) throws IOException {
        CollisionReport result = new CollisionReport(file.toString());
        Iterator<Integer> fingerprints = fingerprinter.getFingerprints(file);
        while (fingerprints.hasNext()) {
            int fingerprint = fingerprints.next();
            result.addFingerprints();
            List<Fingerprint> founds = fingerprintRepository.findByValueAndLanguageId(fingerprint, language.id);
            for (Fingerprint found: founds) {
                result.addCollisionWith(found.getComponent());
            }
        }
        return result;
    }

    public TreeNode<CollisionReport> processTree(File file) throws IOException {
        if (language.checkFile(file)) {
            return new TreeNode<>(processSource(file), new ArrayList<>());
        } else if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children == null) {
                return null;
            }
            List<TreeNode<CollisionReport>> childrenNodes = new ArrayList<>(children.length);
            long totalTokens = 0;
            Map<Component, Long> enoughEverywhere = new HashMap<>();
            Map<Component, Long> notEnoughEverywhere = new HashMap<>();
            for (File child: children) {
                var childNode = processTree(child);
                if (childNode != null) {
                    childrenNodes.add(childNode);
                    for (Component component: childNode.getValue().getCollisions().keySet()) {
                        enoughEverywhere.put(component, 0L);
                        notEnoughEverywhere.put(component, 0L);
                    }
                    totalTokens += childNode.getValue().getTotalFingerprints();
                }
            }
            Map<Component, Long> total = new HashMap<>();
            for (TreeNode<CollisionReport> child: childrenNodes) {
                long totalFingerprints = child.getValue().getTotalFingerprints();
                for (var collision: child.getValue().getCollisions().entrySet()) {
                    total.put(
                            collision.getKey(),
                            total.getOrDefault(collision.getKey(), 0L) + collision.getValue()
                    );
                    if (collision.getValue() * 1.0f / totalFingerprints >= MIN_PERCENT) {
                        notEnoughEverywhere.remove(collision.getKey());
                        if (enoughEverywhere.containsKey(collision.getKey())) {
                            enoughEverywhere.put(
                                    collision.getKey(),
                                    enoughEverywhere.get(collision.getKey())
                                            + collision.getValue()
                            );
                        }
                    } else {
                        enoughEverywhere.remove(collision.getKey());
                        if (notEnoughEverywhere.containsKey(collision.getKey())) {
                            notEnoughEverywhere.put(
                                    collision.getKey(),
                                    notEnoughEverywhere.get(collision.getKey())
                                            + collision.getValue()
                            );
                        }
                        child.getValue().getCollisions().remove(collision.getKey());
                    }
                }
            }
            CollisionReport report = new CollisionReport(file.toString());
            report.addAllCollisions(enoughEverywhere);
            report.addAllCollisions(notEnoughEverywhere);
            report.addFingerprints(totalTokens);
            for (var collision: total.entrySet()) {
                if (!enoughEverywhere.containsKey(collision.getKey())
                        && !notEnoughEverywhere.containsKey(collision.getKey())) {
                    report.addCollisionWith(collision.getKey(), collision.getValue());
                }
            }
            for (var child: childrenNodes) {
                child.getValue().removeBelow(MIN_PERCENT);
                child.getValue().removeAll(enoughEverywhere.keySet());
            }
            return new TreeNode<>(report, childrenNodes);

        } else {
            return null;
        }
    }
}
